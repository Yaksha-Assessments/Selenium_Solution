package coreUtilities.testutils;

public class TestResults {

	private String testCaseResults;
	private String customData;

	public String getTestCaseResults() {
		return testCaseResults;
	}

	public void setTestCaseResults(String testCaseResults) {
		this.testCaseResults = testCaseResults;
	}

	public String getCustomData() {
		return customData;
	}

	public void setCustomData(String customData) {
		this.customData = customData;
	}

}
